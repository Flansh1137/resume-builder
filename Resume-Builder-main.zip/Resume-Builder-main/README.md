# Resume Builder 📄

## Build your resume with us and land on your dream job 🤩.

### This app helps you to build your resume with some of the choosen templates, you can even customise your resume based on your requirements. 

### Technologies that are used in this project.
  <ul>
    <li>React</li> 
    <li>Material UI, for UI</li>  
    <li>JSpdf, for downloading resume.</li> 
    <li>Redux, for state management.</li>  
    <li>React-avatar-edit, for selecting profile image for resume.</li>
    <li>React-router-dom, for routing.</li>
  </ul>
 
 #### Team members    
  <ul>
    <li>Bhabani Shankar Das</li>
    <li>Jagannath Prasad Mohanty</li>
    <li>Vikas Kotari</li>
  </ul>



