import React from "react";
import "../Styles/BlackScreen.css";

const BlackScreen = (props) => {
  return <div className="black-screen"></div>;
};

export default BlackScreen;
