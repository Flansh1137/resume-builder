export const data = {
  personal_info: {
    first_name: "Arjun",
    last_name: "Prakash Mani",
    email: "arjun.prakash@gmail.com",
    mobile: "+911234567890",
    address: "10, Selvapuram, 3rd Street, Mannarai post",
    city: "Tiruppur",
    state: "Tamil Nadu",
    postal_code: "641607",
    objective:
      "Take a tour of our Full Stack Data Science Course to learn about curriculum, assesments and projects designed to help you build a career in data science. Take a tour of our Full Stack Data Science Course to learn about curriculum.",
  },
  work_experience: [
    {
      id: 1,
      job_title: "Human Resource Manager",
      organization_name: "Alma Better",
      start_year: "2018",
      end_year: "2022",
    },
    {
      id: 2,
      job_title: "Human Resource Manager",
      organization_name: "Alma Better",
      start_year: "2018",
      end_year: "2022",
    },
  ],
  education_details: {
    type: "Post Graduation",
    university: "IIT Delhi",
    degree: "B.Tech",
    start_year: "2018",
    end_year: "2022",
  },
  key_skills: ["Python", "Machine Learning", "MERN Stack", "Cloud", "SEO"],
};
